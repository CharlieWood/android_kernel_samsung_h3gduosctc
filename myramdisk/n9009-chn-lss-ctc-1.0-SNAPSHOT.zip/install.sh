#!/sbin/sh

rm -Rf /data/app/com.af.synapse-*
rm -f /data/dalvik-cache/profiles/com.af.synapse
rm -f /system/etc/init.d/*realpac*
rm -Rf /data/data/com.kerneladiutor.mod
